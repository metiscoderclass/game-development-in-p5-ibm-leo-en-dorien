let player;

let floor;
let camera;

let building;
let buildings = [];
let buildingPos;

let score;

let enemy;

let spawnCheck = 0;
let enemies = [];
let fails = 0;
let chance;
let spawnPos;

let bullet;
let bullets = [];

let ellet;
let ellets = [];
let pacman;


function setup() {
  angleMode(DEGREES);
  
  createCanvas(800, 450);
  floor = new Floor(width, 120);
  
  player = new Player(50, floor.height);
  camera = new Camera(player.xPos);
  pacman = new Pacman(player.xPos + width * 2, random(50, 200), 5)
  
  for (var i = 0; i < width / 150; i++) {
    buildingPos = i * 150;
    building = new Building(buildingPos, floor.height);
    buildings.push(building);
  }
  
  score = new Score();
  
}

function draw() {
  background(2, 32, 81);
  
  //moon
  fill(255, 227, 153);
  circle(width/1.2, height/6, 100);
  
  fill(2, 32, 81);
  circle(width/1.2 - 40, height/6, 100);
  
  //floor and camera
  floor.display();
  camera.camera();
  
  //buildings
  for (var i = 0; i < buildings.length; i++)  {
    building = buildings[i];
    building.display();
  }
  
  if (player.xPos >= buildingPos - width) {
    buildingPos += 150;
    building = new Building(buildingPos, floor.height);
    buildings.push(building);
  }
  
  //player
  player.display();
  player.rotation();
  
  player.walk();
  player.jump();
  player.forces();
  
  player.shooting();
  
  //score
  score.display();
  score.math();
  
  //enemies
  spawning();
  
  for (i = 0; i < enemies.length; i++) {
    
    enemy = enemies[i];
    enemy.display();
    enemy.shooting();
    enemy.movement();
    
  }
  
  //bullets
   
  
  for (; i < bullets.length; i++){
    bullet = bullets[i];
    bullet.display();
    bullet.move();
  }
  
  for (; i < ellets.length; i++){
    ellet = ellets[i];
    ellet.display();
    ellet.move();
  }
}

class Bullet {
  constructor(x, y, radius, xSpeed) {
    this.xPos = x;
    this.yPos = y;
    this.radius = radius;
    this.xSpeed = xSpeed;
  }
    display() {
    fill(255 ,100, 100);
    strokeWeight(1);
    noStroke(255, 255, 255);
    
    ellipse(this.xPos, this.yPos-180, this.radius*8, this.radius);
  }
  
  move() {
    this.xPos += this.xSpeed;
  }
}


class Ellet {
  constructor(x, y, radius, xSpeed) {
    this.xPos = x;
    this.yPos = y;
    this.radius = radius;
    this.xSpeed = xSpeed;
  }
    display() {
    fill(255 ,100, 100);
    strokeWeight(1);
    noStroke(255, 255, 255);
    
    ellipse(this.xPos, this.yPos, this.radius*8, this.radius);
  }
  
  move() {
    this.xPos += this.xSpeed;
  }
}

function spawning() {
  spawnCheck += 1;  
  
  if (spawnCheck >= 100) {
    
    if (enemies.length < 1 + score.level) {
        chance = random(0, 100);
        
        chance += fails * 10;
        chance += 10 * score.level;
      
        if (chance >= 70 - score.level * 10) {
          enemy = new Pacman(spawnPos, 100, 20);
          
          enemies.push(enemy);
          console.log('success');
          
          fails = 0;
        }
        else {
          console.log('failure');
          
          fails += 1;
        }
    }
    
    spawnPos = player.xPos + width;
    chance = 0;
    spawnCheck = 0;
  }
}

class Floor {
  constructor(width, floorHeight) {
    this.width = width;
    this.height = height - floorHeight;
  }
  
  display() {
    rectMode(CORNERS);
    fill(0);
    noStroke();
    
    rect(this.width, height, -this.width, this.height);
  }
}

class Player {
  constructor(x, y) {
    
    //position
    this.xPos = x;
    this.yPos = y;
    
    this.width = 50;
    this.height = 80;
    
    //rotation
    this.angle = 0;
    this.rotateSpeed = 0;
    this.rotateSpeedMax = 2;
    this.maxRotation = 0;
    
    //speed
    this.xSpeedMax = 10;
    this.xSpeed = 0;
    
    this.ySpeedMax = 14;
    this.ySpeedMaxFlying = 4;
    this.ySpeed = 0;
    
    //gravity
    this.fallSpeed = 0.5;
    
    //states
    this.walking = false;
    this.jumping = false;
    this.falling = false;
    this.flying = false;
    
    //shooting
    this.shootCooldown = 0;
  }
  
  display() {
    rectMode(CORNER);
    
    push();
    translate(this.xPos, this.yPos - floor.height / 1.5);
    rotate(this.angle);
    
    //jump display
    if (this.jumping === true) {
      fill(0, 255, 0);
      
       strokeWeight(1);
    //feet
    fill(40);
    ellipse(142,217,15,6);
    ellipse(163,217,15,6);
    rect(135,180,7,40);
    quad(150,180,158,180,163,220,155,220);
     //body
    fill(255);
    ellipse(150,90,50);
    fill(255,0,0);
    quad(130,110,170,115,160,180,135,190);
    //jetpack
    fill(200)
    triangle(115,160,100,180,130,180);
    fill(200);
    rect(100,110,30,60,20,0);
    fill(244, 241, 66);
    ellipse(122,120,10);
    fill(255,0,0)
    ellipse(110,120,10);
    fill(244,241,66);
    rect(118,158,12,12);
    fill(200);
    rect(89,130,11,25);
    //gun
    rect(105,145,75,4);
    rect(180,146,30,2);
    rect(110,135,15,10);  
      
    }
    
    //falling display
    else if (this.falling === true) {
      fill(0, 0, 255);
      
      strokeWeight(1);
    //feet
    fill(40);
    ellipse(142,217,15,6);
    ellipse(163,217,15,6);
    rect(135,180,7,40);
    quad(150,180,158,180,163,220,155,220);
     //body
    fill(255);
    ellipse(150,90,50);
    fill(255,0,0);
    quad(130,110,170,115,160,180,135,190);
    //jetpack
    fill(200)
    triangle(115,160,100,180,130,180);
    fill(200);
    rect(100,110,30,60,20,0);
    fill(244, 241, 66);
    ellipse(122,120,10);
    fill(255,0,0)
    ellipse(110,120,10);
    fill(244,241,66);
    rect(118,158,12,12);
    fill(200);
    rect(89,130,11,25);
    //gun
    rect(105,145,75,4);
    rect(180,146,30,2);
    rect(110,135,15,10);  
  }
    
    //walk display
    else if (this.walking === true) {
      fill(255, 0, 0);
      
        strokeWeight(1);
    //feet
    fill(40);
    ellipse(142,217,15,6);
    ellipse(163,217,15,6);
    rect(135,180,7,40);
    quad(150,180,158,180,163,220,155,220);
     //body
    fill(255);
    ellipse(150,90,50);
    fill(255,0,0);
    quad(130,110,170,115,160,180,135,190);
    //jetpack
    fill(200)
    triangle(115,160,100,180,130,180);
    fill(200);
    rect(100,110,30,60,20,0);
    fill(244, 241, 66);
    ellipse(122,120,10);
    fill(255,0,0)
    ellipse(110,120,10);
    fill(244,241,66);
    rect(118,158,12,12);
    fill(200);
    rect(89,130,11,25);
    //gun
    rect(105,145,75,4);
    rect(180,146,30,2);
    rect(110,135,15,10);  
  }
    
    //regular display
    else {
      fill(255);
       
        strokeWeight(1);
  //feet
  fill(40);
  ellipse(142,217,15,6);
  ellipse(163,217,15,6);
  rect(135,180,7,40);
  quad(150,180,158,180,163,220,155,220);
   //body
  fill(255);
  ellipse(150,90,50);
  fill(255,0,0);
  quad(130,110,170,115,160,180,135,190);
  //jetpack
  fill(200)
  triangle(115,160,100,180,130,180);
  fill(200);
  rect(100,110,30,60,20,0);
  fill(244, 241, 66);
  ellipse(122,120,10);
  fill(255,0,0)
  ellipse(110,120,10);
  fill(244,241,66);
  rect(118,158,12,12);
  fill(200);
  rect(89,130,11,25);
  //gun
  rect(105,145,75,4);
  rect(180,146,30,2);
  rect(110,135,15,10);  
    }
    
    pop();
  }
  
  rotation()  {
    if (this.yPos === floor.height)  {
      this.maxRotation = 0;
    }
    else  {
      this.maxRotation = 20;
    }
    
    if (this.angle < this.maxRotation) {
      
    }
    else {
      this.rotateSpeed = 0;
    }
    
    this.angle += this.rotateSpeed;
  }
  
  walk() {
    
    //speed up if pressing arrows
    if (keyIsDown(RIGHT_ARROW)) {
      
      if (this.xSpeed < this.xSpeedMax) {
        this.xSpeed += 1;
        
        this.walking = true;
      }
      
    }
    else if (keyIsDown(LEFT_ARROW)) {
      
      if (this.xSpeed > -this.xSpeedMax) {
        this.xSpeed -= 1;
        
        this.walking = true;
      }
      
    }
    
    //settle back to stationary
    else if (this.xSpeed > 0) {
      this.xSpeed -= 1;
      
      this.walking = false;
    }
    
    else if (this.xSpeed < 0) {
      this.xSpeed += 1;
      
      this.walking = false;
    }
    
  }
  
  jump() {
    //regular jump
    if (keyIsDown(UP_ARROW) && this.yPos === floor.height) {
      
      this.jumping = true;
      
      for (var i = 0; i < this.ySpeedMax; i++) {
        this.ySpeed += 1;
      }
    }
    
    //fly
    else if (keyIsDown(UP_ARROW) && this.jumping === false) {
      
      this.flying = true;
      
      if (this.ySpeed < this.ySpeedMaxFlying) {
        this.ySpeed += 2
      }
      
    }
  }
  
  forces() {
    
    //apply speed
    this.xPos += this.xSpeed;
    this.yPos -= this.ySpeed;
    
    
    //falling if speed below 0
    if (this.ySpeed < 0) {
      
      this.jumping = false;
      
      this.falling = true;
    }
    
    else if (this.yPos <= floor.height) {
      this.falling = false;
    }
    
    
    //gravity
    if (this.yPos < floor.height) {
      this.ySpeed -= this.fallSpeed;
    }
    else if (this.ySpeed < 0) {
      this.ySpeed = 0;
      this.yPos = floor.height;
    }
  }
  
  shooting()  {
    if(keyIsDown(16) && this.shootCooldown >= 10){
    
      bullet = new Bullet(player.xPos+230, player.yPos+107, 5, 30);
      bullets.push(bullet)
    
      this.shootCooldown = 0;
    }
    
    this.shootCooldown += 1;
    
  }
}

class Camera {
  constructor(pos) {
    this.pos = pos;
    this.startPos = pos;
  }
  
  camera() {
    this.pos = -player.xPos + this.startPos;
      
    translate(this.pos, 0);
  }
}

class Building {
  constructor(xPos, yPos) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.width = random(120, 140);
    this.height = random(120, 300);
  }
  
  display() {
    rectMode(CORNER);
    fill(24);
    
    rect(this.xPos, this.yPos, this.width, -this.height);
  }
}

class Score {
  constructor() {
    this.distanceTravelled = 0;
    this.score = 0;
    this.level = 1;
  }
  
  math() {
    this.distanceTravelled = Math.round(-camera.pos / 100);
  }
  
  display() {
    fill(255);
    textSize(20);
    text('Distance travelled: ' + this.distanceTravelled + ' m', -camera.pos + 20, 40);
    text('Level: ' + this.level, -camera.pos + 20, 70);
  }
    
}

class Pacman {
  constructor(x, y, radius) {
    this.xPos = player.xPos + width * 2;
    this.yPos = random(50, 200);
    this.radius = radius;
    
    this.xSpeed = 0;
    this.ySpeed = 0;
    
    this.shootingTimer = 0;
  }
  
  display(){
    strokeWeight(2)
    fill(247,247,2)
    
    strokeWeight(2)
    fill(114, 115, 117)
    triangle(this.xPos - 30, this.yPos + 70, this.xPos, this.yPos + 30, this.xPos + 30, this.yPos + 70)
    fill(247,247,2)
    arc(this.xPos,this.yPos,100, 100, 210, 150, PIE)
  
    //eye
    fill(114, 2, 13)
    arc(this.xPos - 10, this.yPos - 30, 25, 25, 2100, 170, CHORD);
  }
  
  shooting() {
    if (this.shootingTimer >= 100)  {
      if (this.yPos >= player.yPos - 20 && this.yPos < player.yPos + 20)  {
        this.shootingTimer = 0;
        
        
        ellet = new Ellet(this.xPos, this.yPos, 5, -10);
        ellets.push(ellet)
        
      }
    }
    else {
      this.shootingTimer += 1;
    }
    
  }
  
  movement() {
    this.yPos += this.ySpeed
    
    if (player.xPos + 450 < this.xPos)  {
      this.xPos -= 5;
    }
    else if (player.xPos > this.xPos)  {
      var i = 0;
      while (i * 8 < player.xPos + 100)  {
        this.xPos += 1;
        i++;
      }
      
    }
    
    if (this.shootingTimer >= 100 && this.xPos > player.xPos + 150 && this.xPos < player.xPos + width - 200)  {
      
      if (this.yPos + 30 < player.yPos)  {
        this.yPos += 3;
      }
      else if (this.yPos > player.yPos)  {
        this.yPos -= 3;
      }

    }
    
  }
}
